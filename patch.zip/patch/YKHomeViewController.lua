waxClass{"YKHomeViewController", UIViewController}


function setupRefreshTableViewDataArrayData(self)
	self:setDataArray(nil);
	local homeParser =  YKHomeParser:jsonParserWithSelfClass()
	homeParser:setSourceData(nil)
	if self:userIsLogin == 0 
		then
		self:dataArray:addObject(homeParser:homeInfo.bannerItems)
		self:dataArray:addObject(homeParser.homeInfo)
	else
		self:dataArray:addObject(homeParser.homeInfo.earningsInfo)
		self:dataArray:addObject(homeParser.homeInfo.projectInfo)
	end

end
