waxClass{"ViewController", UIViewController}


function handleTestEvent(self, sender)
	
	

end
