waxClass{"YKHomeViewController", UIViewController}


function lookDetailProjectEvent(self)
	
	

end
